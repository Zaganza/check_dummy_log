from setuptools import setup, find_packages

setup(
    name='check_dummy_log_package',
    version='',
    packages=find_packages(),
    install_requires=[
        'requests',
    ],
    entry_points={
        'console_scripts': [
            'report-abuseip=check_dummy_log_package.main:main',
            'generate-logs=check_dummy_log_package.generate_logs:main',
        ],
    },
    package_data={
        'check_dummy_log_package': ['dummy_logs.txt']
    },
    include_package_data=True,
    author='NK',
    author_email='...',
    description='Application for querying AbuseIPDB based on dummy log entries',
    license='MIT',
    keywords='AbuseIPDB security log-analysis',
    url='https://github.com/Zaganza/my-abuseipdb-app',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)