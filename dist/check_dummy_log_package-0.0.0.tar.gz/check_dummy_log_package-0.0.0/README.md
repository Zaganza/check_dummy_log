# My AbuseIPDB App

This application reads a log file, queries AbuseIPDB for information about the IP addresses in the log, and outputs the results to both the console and a text file.

## Usage

1. Generate dummy logs:
    ```sh
    python -m check_dummy_log_package.generate_logs
    ```

2. Run the main application:
    ```sh
    python -m check_dummy_log_package.main
    ```

3. The output will be displayed in the console and saved to `abuseipdb_report.txt`.